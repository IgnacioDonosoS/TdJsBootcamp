function cambiarColor(id) {
   document.getElementById("caja").style.backgroundColor = document.getElementById(id).style.backgroundColor;
  }